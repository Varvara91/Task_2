'use strict'



function convIn16(){
	var text1 = +document.getElementById("input1_1").value;
	var text2 = +document.getElementById("input1_2").value;
	var text3 = +document.getElementById("input1_3").value;
		if (isNaN(text1)) {
			alert('Неправильно введено первое число');
			return null;
		} else if (isNaN(text2)) {
			alert('Неправильно введено второе число');
			return null;
			}
		else if (isNaN(text3)) {
			alert('Неправильно введено третье число');
			return null;
			} 

	var a1 = (text1).toString(16);
	var a2 = (text2).toString(16);
	var a3 = (text3).toString(16);
	var a = '';
	console.log(a1);
	a = ('Первое число: '+ a1 +'<br>' + 'Второе число: '+ a2+'<br>' + 'Третье число: '+ a3);

	return document.getElementById("text").innerHTML = a;

}

//////////////////////////////////////////////////////////////



function convInObj(){
	var number = document.getElementById("input2_1").value;
			if (isNaN(number)){
				alert('Неправильный ввод!');
				return null;
			} else if (+number>999) {
				alert('Слишком большое число!');
				return null;
			}

		var obj = {};

		if (+number>=100){
		obj.ed = number.charAt(2);
		obj.des = number.charAt(1);
		obj.hun = number.charAt(0);
		return document.getElementById("text").innerHTML = ('Единицы: ' + obj.ed + '<br>' + 'Десятки: ' + obj.des + '<br>' + 'Сотни: ' + obj.hun);
	
	} else if (+number>=10) {
		obj.ed = number.charAt(1);
		obj.des = number.charAt(0);
		return document.getElementById("text").innerHTML = ('Единицы: ' + obj.ed + '<br>' + 'Десятки: ' + obj.des);

	} else if (+number>=0) {
		return document.getElementById("text").innerHTML = ('Единицы: ' + number);
}
}

//////////////////////////////////////////////////////////////

function objectToQueryString() {

var x = {name: document.getElementById("input0").value, name2: document.getElementById("input1").value, name3: document.getElementById("input2").value};

	var firstName = ('имя=' + x.name);
	var surName = ('фамилия=' + x.name2);
	var age = ('возраст=' + x.name3);

	return document.getElementById("text").innerHTML = (firstName + '&' + surName + '&' + age);
}